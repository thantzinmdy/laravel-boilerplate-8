<?php

namespace Nwidart\Modules\Exceptions;

class ModuleNotFoundException extends \Exception
{
}
